Pour la bonne exécution du code, il faut créer plusieurs connexion depuis le pilote ODBC 64. Elles seront otutes connectées à la base de données nondenot_bd9 disponible sur le serveur PhpMyAdmin lakartxela.iutbayonne.univ-pau.fr.
Une première avec le DSN : Cmourgue_BD_S201
Une deuxième avec le DSN : Cmourgue_BD_Diapo_S201
Une troisième avec le DSN : Cmourgue_BD_Image_S201
Une dernière avec le DSN : Cmourgue_BD_Form_S201